/*
    Library.h
    -----------------------------------------------------
    The Library class is the central controller of the
    application. It holds all Books, Members, and Issue
    records in memory (loaded from files at startup) and
    exposes high-level operations that main.cpp calls from
    the menu. Every operation that changes data also saves
    the changes back to the relevant file, so records are
    permanent across program runs.
    -----------------------------------------------------
*/

#ifndef LIBRARY_H
#define LIBRARY_H

#include <string>
#include <vector>
#include "Book.h"
#include "Member.h"

// ---------------------------------------------------------
// IssueRecord represents one row in issues.txt:
// which book was issued to which member, when, and whether
// it has been returned yet.
// ---------------------------------------------------------
struct IssueRecord {
    int issueID;
    int bookID;
    int memberID;
    std::string issueDate;
    std::string returnDate;   // "N/A" while still issued
    std::string status;       // "Issued" or "Returned"

    IssueRecord();
    IssueRecord(int issueID, int bookID, int memberID,
                const std::string& issueDate, const std::string& returnDate,
                const std::string& status);

    std::string toFileString() const;
    static IssueRecord fromFileString(const std::string& line);
    void display() const;
};

class Library {
private:
    std::vector<Book> books;
    std::vector<Member> members;
    std::vector<IssueRecord> issues;

    // File names used for persistent storage.
    const std::string BOOKS_FILE   = "books.txt";
    const std::string MEMBERS_FILE = "members.txt";
    const std::string ISSUES_FILE  = "issues.txt";

    // Helpers to persist the current in-memory state to disk.
    void saveBooksToFile() const;
    void saveMembersToFile() const;
    void saveIssuesToFile() const;

    // Helpers to generate the next available unique ID.
    int getNextBookID() const;
    int getNextMemberID() const;
    int getNextIssueID() const;

    // Helper to get today's date as a string (YYYY-MM-DD).
    static std::string getCurrentDate();

public:
    // Loads all records from the text files into memory.
    Library();

    // ---------------- Book Operations ----------------
    void addBook();
    void displayAllBooks() const;
    void searchBook() const;
    void updateBook();
    void deleteBook();

    // ---------------- Member Operations ----------------
    void registerMember();
    void displayAllMembers() const;
    void deleteMember();

    // ---------------- Issue / Return Operations ----------------
    void issueBook();
    void returnBook();
    void displayIssuedBooks() const;

    // ---------------- Statistics ----------------
    void showStatistics() const;

    // ---------------- Existence Checks ----------------
    bool bookIDExists(int id) const;
    bool memberIDExists(int id) const;
    int  findBookIndex(int id) const;
    int  findMemberIndex(int id) const;
};

#endif // LIBRARY_H
