/*
    Book.h
    -----------------------------------------------------
    Represents a single Book record in the library.
    Demonstrates encapsulation: all fields are private and
    accessed only through public getters/setters.
    -----------------------------------------------------
*/

#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    int bookID;
    std::string title;
    std::string author;
    std::string category;
    std::string isbn;
    int publicationYear;
    int totalCopies;
    int availableCopies;

public:
    // Default constructor
    Book();

    // Parameterized constructor
    Book(int bookID,
         const std::string& title,
         const std::string& author,
         const std::string& category,
         const std::string& isbn,
         int publicationYear,
         int totalCopies,
         int availableCopies);

    // ---------------- Getters ----------------
    int getBookID() const;
    std::string getTitle() const;
    std::string getAuthor() const;
    std::string getCategory() const;
    std::string getISBN() const;
    int getPublicationYear() const;
    int getTotalCopies() const;
    int getAvailableCopies() const;

    // ---------------- Setters ----------------
    void setTitle(const std::string& title);
    void setAuthor(const std::string& author);
    void setCategory(const std::string& category);
    void setISBN(const std::string& isbn);
    void setPublicationYear(int year);
    void setTotalCopies(int copies);
    void setAvailableCopies(int copies);

    // Increases/decreases available copies (used for issue/return).
    void decrementAvailableCopies();
    void incrementAvailableCopies();

    // ---------------- File Handling ----------------
    // Converts this Book object into a single pipe-delimited
    // line for storage in books.txt
    std::string toFileString() const;

    // Reconstructs a Book object from a pipe-delimited line
    // that was read from books.txt
    static Book fromFileString(const std::string& line);

    // Prints book details neatly to the console.
    void display() const;
};

#endif // BOOK_H
