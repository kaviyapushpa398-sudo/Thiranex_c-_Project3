/*
    Member.h
    -----------------------------------------------------
    Represents a single library Member record.
    -----------------------------------------------------
*/

#ifndef MEMBER_H
#define MEMBER_H

#include <string>

class Member {
private:
    int memberID;
    std::string name;
    std::string phone;
    std::string address;

public:
    // Default constructor
    Member();

    // Parameterized constructor
    Member(int memberID,
           const std::string& name,
           const std::string& phone,
           const std::string& address);

    // ---------------- Getters ----------------
    int getMemberID() const;
    std::string getName() const;
    std::string getPhone() const;
    std::string getAddress() const;

    // ---------------- Setters ----------------
    void setName(const std::string& name);
    void setPhone(const std::string& phone);
    void setAddress(const std::string& address);

    // ---------------- File Handling ----------------
    std::string toFileString() const;
    static Member fromFileString(const std::string& line);

    void display() const;
};

#endif // MEMBER_H
