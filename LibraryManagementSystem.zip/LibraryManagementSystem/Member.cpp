/*
    Member.cpp
    -----------------------------------------------------
    Implementation of the Member class.
    -----------------------------------------------------
*/

#include "Member.h"
#include "FileHandler.h"
#include <iostream>
#include <iomanip>
#include <sstream>

// ---------------- Constructors ----------------

Member::Member() : memberID(0), name(""), phone(""), address("") {}

Member::Member(int memberID,
               const std::string& name,
               const std::string& phone,
               const std::string& address)
    : memberID(memberID), name(name), phone(phone), address(address) {
}

// ---------------- Getters ----------------

int Member::getMemberID() const { return memberID; }
std::string Member::getName() const { return name; }
std::string Member::getPhone() const { return phone; }
std::string Member::getAddress() const { return address; }

// ---------------- Setters ----------------

void Member::setName(const std::string& n) { name = n; }
void Member::setPhone(const std::string& p) { phone = p; }
void Member::setAddress(const std::string& a) { address = a; }

// ---------------- File Handling ----------------

std::string Member::toFileString() const {
    std::ostringstream oss;
    oss << memberID << "|" << name << "|" << phone << "|" << address;
    return oss.str();
}

Member Member::fromFileString(const std::string& line) {
    std::vector<std::string> fields = FileHandler::split(line, '|');

    if (fields.size() < 4) {
        return Member(); // invalid/default member
    }

    int id = std::stoi(fields[0]);
    std::string name = fields[1];
    std::string phone = fields[2];
    std::string address = fields[3];

    return Member(id, name, phone, address);
}

void Member::display() const {
    std::cout << std::left
              << std::setw(6)  << memberID
              << std::setw(20) << name
              << std::setw(15) << phone
              << std::setw(30) << address
              << std::endl;
}
