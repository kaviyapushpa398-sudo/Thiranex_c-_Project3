/*
    main.cpp
    -----------------------------------------------------
    Library Management System — Console Application
    -----------------------------------------------------
    Entry point of the program. Displays a menu-driven
    interface and delegates all real work to the Library
    class, which itself uses Book, Member, and FileHandler
    to manage permanent, file-based storage.

    Compile (example):
        g++ -std=c++17 main.cpp Book.cpp Member.cpp Library.cpp FileHandler.cpp -o library_system

    Run:
        ./library_system      (Linux/Mac)
        library_system.exe    (Windows)
    -----------------------------------------------------
*/

#include <iostream>
#include <limits>
#include "Library.h"

// Prints the main menu banner.
void printMenu() {
    std::cout << "\n===============================\n";
    std::cout << "     LIBRARY MANAGEMENT SYSTEM\n";
    std::cout << "===============================\n";
    std::cout << "1.  Add Book\n";
    std::cout << "2.  Display Books\n";
    std::cout << "3.  Search Book\n";
    std::cout << "4.  Register Member\n";
    std::cout << "5.  Display Members\n";
    std::cout << "6.  Issue Book\n";
    std::cout << "7.  Return Book\n";
    std::cout << "8.  Update Book\n";
    std::cout << "9.  Delete Book\n";
    std::cout << "10. Delete Member\n";
    std::cout << "11. Issued Books\n";
    std::cout << "12. Statistics\n";
    std::cout << "13. Exit\n";
    std::cout << "===============================\n";
    std::cout << "Enter your choice: ";
}

int main() {
    Library library; // Loads all existing data from books.txt, members.txt, issues.txt

    std::cout << "Welcome to the Library Management System!\n";

    bool running = true;
    while (running) {
        printMenu();

        int choice;
        std::cin >> choice;

        // Guard against non-numeric menu input.
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Invalid input. Please enter a number between 1 and 13.\n";
            continue;
        }
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        switch (choice) {
            case 1:  library.addBook();            break;
            case 2:  library.displayAllBooks();     break;
            case 3:  library.searchBook();          break;
            case 4:  library.registerMember();      break;
            case 5:  library.displayAllMembers();   break;
            case 6:  library.issueBook();           break;
            case 7:  library.returnBook();          break;
            case 8:  library.updateBook();          break;
            case 9:  library.deleteBook();          break;
            case 10: library.deleteMember();        break;
            case 11: library.displayIssuedBooks();  break;
            case 12: library.showStatistics();      break;
            case 13:
                std::cout << "Thank you for using the Library Management System. Goodbye!\n";
                running = false;
                break;
            default:
                std::cout << "Invalid choice. Please enter a number between 1 and 13.\n";
                break;
        }
    }

    return 0;
}
