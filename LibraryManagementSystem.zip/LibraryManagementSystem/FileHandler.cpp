/*
    FileHandler.cpp
    -----------------------------------------------------
    Implementation of the FileHandler utility class.
    Uses <fstream> for file handling and <sstream> for
    splitting delimited record lines.
    -----------------------------------------------------
*/

#include "FileHandler.h"
#include <fstream>
#include <sstream>

// ---------------------------------------------------------
// Reads all lines from a file. Returns an empty vector if
// the file cannot be opened (e.g. it does not exist yet).
// ---------------------------------------------------------
std::vector<std::string> FileHandler::readLines(const std::string& filename) {
    std::vector<std::string> lines;
    std::ifstream inFile(filename.c_str());

    if (!inFile.is_open()) {
        // Not fatal: simply means no records exist yet.
        return lines;
    }

    std::string line;
    while (std::getline(inFile, line)) {
        if (!line.empty()) {
            lines.push_back(line);
        }
    }

    inFile.close();
    return lines;
}

// ---------------------------------------------------------
// Overwrites the entire file with the supplied lines.
// Used after edit/delete operations to keep the file in
// sync with the in-memory data.
// ---------------------------------------------------------
bool FileHandler::writeLines(const std::string& filename, const std::vector<std::string>& lines) {
    std::ofstream outFile(filename.c_str(), std::ios::out | std::ios::trunc);

    if (!outFile.is_open()) {
        return false;
    }

    for (const auto& line : lines) {
        outFile << line << "\n";
    }

    outFile.close();
    return true;
}

// ---------------------------------------------------------
// Appends one new record line to the end of the file.
// ---------------------------------------------------------
bool FileHandler::appendLine(const std::string& filename, const std::string& line) {
    std::ofstream outFile(filename.c_str(), std::ios::out | std::ios::app);

    if (!outFile.is_open()) {
        return false;
    }

    outFile << line << "\n";
    outFile.close();
    return true;
}

// ---------------------------------------------------------
// Splits a string by a delimiter character into fields.
// Example: split("1|Harry Potter|Rowling", '|')
//          -> ["1", "Harry Potter", "Rowling"]
// ---------------------------------------------------------
std::vector<std::string> FileHandler::split(const std::string& line, char delimiter) {
    std::vector<std::string> tokens;
    std::stringstream ss(line);
    std::string token;

    while (std::getline(ss, token, delimiter)) {
        tokens.push_back(token);
    }

    return tokens;
}

// ---------------------------------------------------------
// Checks if a given file already exists on disk.
// ---------------------------------------------------------
bool FileHandler::fileExists(const std::string& filename) {
    std::ifstream f(filename.c_str());
    return f.good();
}
