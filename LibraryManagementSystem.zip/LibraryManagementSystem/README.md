# Library Management System (C++)

A menu-driven, console-based Library Management System built with C++,
Object-Oriented Programming, and file handling. All data (books, members,
and issue records) is stored permanently in plain text files so it
persists between program runs.

## Features

1. Add New Book
2. Display All Books
3. Search Book (by ID, Title, or Author)
4. Register New Member
5. Display All Members
6. Issue Book (with availability check)
7. Return Book
8. Update Book Details
9. Delete Book (blocked if copies are currently issued)
10. Delete Member (blocked if they have books issued)
11. Display Issued Books
12. Show Statistics (total books, copies, members, active issues)
13. Exit

## Project Structure

```
LibraryManagementSystem/
├── main.cpp          # Program entry point and menu loop
├── Book.h / Book.cpp  # Book class (encapsulated fields + file (de)serialization)
├── Member.h / Member.cpp  # Member class
├── Library.h / Library.cpp # Core business logic, IssueRecord, validation
├── FileHandler.h / FileHandler.cpp # Generic file read/write/split utilities
├── books.txt          # Persistent book records (sample data included)
├── members.txt         # Persistent member records (sample data included)
├── issues.txt          # Persistent issue/return records (sample data included)
└── README.md
```

## Design Overview

- **Encapsulation**: `Book` and `Member` keep their fields `private` and
  expose controlled access through getters/setters.
- **Single Responsibility**: `FileHandler` only knows how to read/write/split
  text files; it has no knowledge of books or members. `Library` owns all
  business rules (uniqueness, availability, validation) and uses
  `FileHandler` for persistence.
- **File Format**: Each record is stored as one line with fields separated
  by a pipe character (`|`), which keeps parsing simple while still
  allowing spaces/commas inside titles, names, and addresses.
  - `books.txt`: `BookID|Title|Author|Category|ISBN|Year|TotalCopies|AvailableCopies`
  - `members.txt`: `MemberID|Name|Phone|Address`
  - `issues.txt`: `IssueID|BookID|MemberID|IssueDate|ReturnDate|Status`
- **IDs**: Book IDs and Member IDs are auto-generated (max existing ID + 1)
  to guarantee uniqueness. Duplicate books are additionally prevented by
  checking for a matching ISBN.
- **Data Integrity Rules**:
  - A book cannot be issued if it has zero available copies.
  - A book cannot be deleted while any copy of it is currently issued.
  - A member cannot be deleted while they currently hold an issued book.
  - Returning a book that was already returned is rejected.

## Building

### Linux / macOS
```bash
g++ -std=c++17 -Wall -Wextra main.cpp Book.cpp Member.cpp Library.cpp FileHandler.cpp -o library_system
./library_system
```

### Windows (MSYS2 / MinGW)
Open the **MSYS2 MinGW 64-bit** terminal, `cd` into the project folder, then run:
```bash
g++ -std=c++17 -Wall -Wextra main.cpp Book.cpp Member.cpp Library.cpp FileHandler.cpp -o library_system.exe
./library_system.exe
```

> Make sure `g++` is on your PATH (installed via `pacman -S mingw-w64-x86_64-gcc`
> in MSYS2, then using the "MSYS2 MinGW 64-bit" shortcut so the compiler
> targets native Windows executables).

The program creates/updates `books.txt`, `members.txt`, and `issues.txt` in
the **current working directory**, so run the executable from inside the
project folder (where these files live) to keep your data together.

## Sample Data

The repository ships with a few sample books, members, and issue records
already populated so you can explore every menu option immediately without
starting from an empty library. Feel free to delete the contents of the
`.txt` files (keep the files themselves) if you'd rather start fresh.

## Notes for Beginners

- Every class has clear, commented header files describing what each
  method does — start there if you want to understand the design before
  diving into the `.cpp` implementations.
- Input validation loops (e.g. `readInt`, `readPositiveInt`, `readLine` in
  `Library.cpp`) show a common, reusable pattern for safely reading user
  input in C++ console apps.
- Because the whole project is split into small, focused files, you can
  extend it feature-by-feature — for example, adding a "Renew Book" option
  mainly touches `Library.h`/`Library.cpp` and `main.cpp`.
