/*
    Book.cpp
    -----------------------------------------------------
    Implementation of the Book class.
    -----------------------------------------------------
*/

#include "Book.h"
#include "FileHandler.h"
#include <iostream>
#include <iomanip>
#include <sstream>

// ---------------- Constructors ----------------

Book::Book()
    : bookID(0), title(""), author(""), category(""), isbn(""),
      publicationYear(0), totalCopies(0), availableCopies(0) {
}

Book::Book(int bookID,
           const std::string& title,
           const std::string& author,
           const std::string& category,
           const std::string& isbn,
           int publicationYear,
           int totalCopies,
           int availableCopies)
    : bookID(bookID), title(title), author(author), category(category),
      isbn(isbn), publicationYear(publicationYear),
      totalCopies(totalCopies), availableCopies(availableCopies) {
}

// ---------------- Getters ----------------

int Book::getBookID() const { return bookID; }
std::string Book::getTitle() const { return title; }
std::string Book::getAuthor() const { return author; }
std::string Book::getCategory() const { return category; }
std::string Book::getISBN() const { return isbn; }
int Book::getPublicationYear() const { return publicationYear; }
int Book::getTotalCopies() const { return totalCopies; }
int Book::getAvailableCopies() const { return availableCopies; }

// ---------------- Setters ----------------

void Book::setTitle(const std::string& t) { title = t; }
void Book::setAuthor(const std::string& a) { author = a; }
void Book::setCategory(const std::string& c) { category = c; }
void Book::setISBN(const std::string& i) { isbn = i; }
void Book::setPublicationYear(int y) { publicationYear = y; }
void Book::setTotalCopies(int c) { totalCopies = c; }
void Book::setAvailableCopies(int c) { availableCopies = c; }

void Book::decrementAvailableCopies() {
    if (availableCopies > 0) availableCopies--;
}

void Book::incrementAvailableCopies() {
    if (availableCopies < totalCopies) availableCopies++;
}

// ---------------- File Handling ----------------

// Fields are separated by '|' so titles/authors can safely
// contain spaces and commas.
std::string Book::toFileString() const {
    std::ostringstream oss;
    oss << bookID << "|" << title << "|" << author << "|" << category << "|"
        << isbn << "|" << publicationYear << "|" << totalCopies << "|" << availableCopies;
    return oss.str();
}

Book Book::fromFileString(const std::string& line) {
    std::vector<std::string> fields = FileHandler::split(line, '|');

    // Guard against malformed/incomplete lines.
    if (fields.size() < 8) {
        return Book(); // returns a default/invalid book
    }

    int id = std::stoi(fields[0]);
    std::string title = fields[1];
    std::string author = fields[2];
    std::string category = fields[3];
    std::string isbn = fields[4];
    int year = std::stoi(fields[5]);
    int total = std::stoi(fields[6]);
    int available = std::stoi(fields[7]);

    return Book(id, title, author, category, isbn, year, total, available);
}

void Book::display() const {
    std::cout << std::left
              << std::setw(6)  << bookID
              << std::setw(25) << title
              << std::setw(20) << author
              << std::setw(15) << category
              << std::setw(15) << isbn
              << std::setw(8)  << publicationYear
              << std::setw(8)  << totalCopies
              << std::setw(10) << availableCopies
              << std::endl;
}
