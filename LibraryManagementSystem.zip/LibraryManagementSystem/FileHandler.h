/*
    FileHandler.h
    -----------------------------------------------------
    A small utility class that centralizes ALL raw file
    input/output for the Library Management System.

    Every other class (Book, Member, Library) relies on
    FileHandler to read/write plain text files so that the
    file-handling logic lives in exactly one place.
    -----------------------------------------------------
*/

#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <string>
#include <vector>

class FileHandler {
public:
    // Reads every line of a text file into a vector of strings.
    // If the file does not exist, an empty vector is returned
    // (the file is NOT treated as an error, since a brand-new
    // library may not have created the file yet).
    static std::vector<std::string> readLines(const std::string& filename);

    // Overwrites the file with the given lines (used after
    // updates/deletes so the file always matches memory).
    static bool writeLines(const std::string& filename, const std::vector<std::string>& lines);

    // Appends a single line to the end of a file (used when
    // adding a brand-new record).
    static bool appendLine(const std::string& filename, const std::string& line);

    // Splits a delimited record line (e.g. "1|Title|Author")
    // into its individual fields.
    static std::vector<std::string> split(const std::string& line, char delimiter);

    // Checks whether a file already exists on disk.
    static bool fileExists(const std::string& filename);
};

#endif // FILEHANDLER_H
