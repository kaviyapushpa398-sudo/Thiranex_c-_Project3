/*
    Library.cpp
    -----------------------------------------------------
    Implementation of the Library class and IssueRecord
    struct. Contains all core business logic: adding,
    searching, updating, deleting books/members, and
    issuing/returning books, with input validation and
    permanent file storage.
    -----------------------------------------------------
*/

#include "Library.h"
#include "FileHandler.h"
#include <iostream>
#include <iomanip>
#include <limits>
#include <algorithm>
#include <ctime>
#include <sstream>

// ===========================================================
//                      IssueRecord
// ===========================================================

IssueRecord::IssueRecord()
    : issueID(0), bookID(0), memberID(0), issueDate(""), returnDate(""), status("") {
}

IssueRecord::IssueRecord(int issueID, int bookID, int memberID,
                          const std::string& issueDate, const std::string& returnDate,
                          const std::string& status)
    : issueID(issueID), bookID(bookID), memberID(memberID),
      issueDate(issueDate), returnDate(returnDate), status(status) {
}

std::string IssueRecord::toFileString() const {
    std::ostringstream oss;
    oss << issueID << "|" << bookID << "|" << memberID << "|"
        << issueDate << "|" << returnDate << "|" << status;
    return oss.str();
}

IssueRecord IssueRecord::fromFileString(const std::string& line) {
    std::vector<std::string> fields = FileHandler::split(line, '|');
    if (fields.size() < 6) {
        return IssueRecord();
    }
    int issueID = std::stoi(fields[0]);
    int bookID = std::stoi(fields[1]);
    int memberID = std::stoi(fields[2]);
    std::string issueDate = fields[3];
    std::string returnDate = fields[4];
    std::string status = fields[5];

    return IssueRecord(issueID, bookID, memberID, issueDate, returnDate, status);
}

void IssueRecord::display() const {
    std::cout << std::left
              << std::setw(10) << issueID
              << std::setw(10) << bookID
              << std::setw(12) << memberID
              << std::setw(14) << issueDate
              << std::setw(14) << returnDate
              << std::setw(10) << status
              << std::endl;
}

// ===========================================================
//               Small local input-validation helpers
// ===========================================================
namespace {

    // Reads an integer safely, re-prompting on invalid input.
    int readInt(const std::string& prompt) {
        int value;
        while (true) {
            std::cout << prompt;
            std::cin >> value;
            if (std::cin.fail()) {
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
                std::cout << "Invalid input. Please enter a whole number.\n";
                continue;
            }
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return value;
        }
    }

    // Reads a positive integer (> 0).
    int readPositiveInt(const std::string& prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) return value;
            std::cout << "Value must be greater than zero.\n";
        }
    }

    // Reads a non-empty line of text.
    std::string readLine(const std::string& prompt) {
        std::string line;
        while (true) {
            std::cout << prompt;
            std::getline(std::cin, line);
            if (!line.empty()) return line;
            std::cout << "Input cannot be empty. Please try again.\n";
        }
    }

    // Converts a string to lowercase for case-insensitive search.
    std::string toLower(const std::string& s) {
        std::string result = s;
        std::transform(result.begin(), result.end(), result.begin(), ::tolower);
        return result;
    }
}

// ===========================================================
//                      Library
// ===========================================================

Library::Library() {
    // Load persisted records from disk into memory at startup.
    std::vector<std::string> bookLines = FileHandler::readLines(BOOKS_FILE);
    for (const auto& line : bookLines) {
        books.push_back(Book::fromFileString(line));
    }

    std::vector<std::string> memberLines = FileHandler::readLines(MEMBERS_FILE);
    for (const auto& line : memberLines) {
        members.push_back(Member::fromFileString(line));
    }

    std::vector<std::string> issueLines = FileHandler::readLines(ISSUES_FILE);
    for (const auto& line : issueLines) {
        issues.push_back(IssueRecord::fromFileString(line));
    }
}

// ---------------- Persistence helpers ----------------

void Library::saveBooksToFile() const {
    std::vector<std::string> lines;
    for (const auto& b : books) lines.push_back(b.toFileString());
    FileHandler::writeLines(BOOKS_FILE, lines);
}

void Library::saveMembersToFile() const {
    std::vector<std::string> lines;
    for (const auto& m : members) lines.push_back(m.toFileString());
    FileHandler::writeLines(MEMBERS_FILE, lines);
}

void Library::saveIssuesToFile() const {
    std::vector<std::string> lines;
    for (const auto& i : issues) lines.push_back(i.toFileString());
    FileHandler::writeLines(ISSUES_FILE, lines);
}

// ---------------- ID generation ----------------

int Library::getNextBookID() const {
    int maxID = 0;
    for (const auto& b : books) maxID = std::max(maxID, b.getBookID());
    return maxID + 1;
}

int Library::getNextMemberID() const {
    int maxID = 0;
    for (const auto& m : members) maxID = std::max(maxID, m.getMemberID());
    return maxID + 1;
}

int Library::getNextIssueID() const {
    int maxID = 0;
    for (const auto& i : issues) maxID = std::max(maxID, i.issueID);
    return maxID + 1;
}

std::string Library::getCurrentDate() {
    std::time_t t = std::time(nullptr);
    std::tm* now = std::localtime(&t);
    char buffer[32];
    std::snprintf(buffer, sizeof(buffer), "%04d-%02d-%02d",
                  now->tm_year + 1900, now->tm_mon + 1, now->tm_mday);
    return std::string(buffer);
}

// ---------------- Existence checks ----------------

bool Library::bookIDExists(int id) const {
    for (const auto& b : books) if (b.getBookID() == id) return true;
    return false;
}

bool Library::memberIDExists(int id) const {
    for (const auto& m : members) if (m.getMemberID() == id) return true;
    return false;
}

int Library::findBookIndex(int id) const {
    for (size_t i = 0; i < books.size(); ++i)
        if (books[i].getBookID() == id) return static_cast<int>(i);
    return -1;
}

int Library::findMemberIndex(int id) const {
    for (size_t i = 0; i < members.size(); ++i)
        if (members[i].getMemberID() == id) return static_cast<int>(i);
    return -1;
}

// ===========================================================
//                   Book Operations
// ===========================================================

void Library::addBook() {
    std::cout << "\n--- Add New Book ---\n";

    // Book ID is auto-generated to guarantee uniqueness, but we
    // still show it to the user and allow a manual override check.
    int suggestedID = getNextBookID();
    std::cout << "Assigned Book ID: " << suggestedID << "\n";

    std::string title = readLine("Enter Title: ");
    std::string author = readLine("Enter Author: ");
    std::string category = readLine("Enter Category: ");
    std::string isbn = readLine("Enter ISBN: ");

    // Prevent duplicate book entries based on identical ISBN.
    for (const auto& b : books) {
        if (b.getISBN() == isbn) {
            std::cout << "Error: A book with this ISBN already exists (Book ID "
                      << b.getBookID() << "). Duplicate entry rejected.\n";
            return;
        }
    }

    int year = readPositiveInt("Enter Publication Year: ");
    int copies = readPositiveInt("Enter Number of Copies: ");

    Book newBook(suggestedID, title, author, category, isbn, year, copies, copies);
    books.push_back(newBook);
    saveBooksToFile();

    std::cout << "Success: Book added with ID " << suggestedID << ".\n";
}

void Library::displayAllBooks() const {
    std::cout << "\n--- All Books (" << books.size() << ") ---\n";
    if (books.empty()) {
        std::cout << "No books found in the library.\n";
        return;
    }

    std::cout << std::left
              << std::setw(6)  << "ID"
              << std::setw(25) << "Title"
              << std::setw(20) << "Author"
              << std::setw(15) << "Category"
              << std::setw(15) << "ISBN"
              << std::setw(8)  << "Year"
              << std::setw(8)  << "Total"
              << std::setw(10) << "Available"
              << std::endl;
    std::cout << std::string(107, '-') << std::endl;

    for (const auto& b : books) b.display();
}

void Library::searchBook() const {
    std::cout << "\n--- Search Book ---\n";
    std::cout << "1. By Book ID\n2. By Title\n3. By Author\n";
    int choice = readInt("Enter choice: ");

    bool found = false;

    if (choice == 1) {
        int id = readInt("Enter Book ID: ");
        for (const auto& b : books) {
            if (b.getBookID() == id) {
                found = true;
                std::cout << std::left
                          << std::setw(6) << "ID" << std::setw(25) << "Title"
                          << std::setw(20) << "Author" << std::setw(15) << "Category"
                          << std::setw(15) << "ISBN" << std::setw(8) << "Year"
                          << std::setw(8) << "Total" << std::setw(10) << "Available" << std::endl;
                b.display();
                break;
            }
        }
    } else if (choice == 2) {
        std::string title = readLine("Enter Title (or part of it): ");
        std::string titleLower = toLower(title);
        for (const auto& b : books) {
            if (toLower(b.getTitle()).find(titleLower) != std::string::npos) {
                if (!found) {
                    std::cout << std::left
                              << std::setw(6) << "ID" << std::setw(25) << "Title"
                              << std::setw(20) << "Author" << std::setw(15) << "Category"
                              << std::setw(15) << "ISBN" << std::setw(8) << "Year"
                              << std::setw(8) << "Total" << std::setw(10) << "Available" << std::endl;
                }
                b.display();
                found = true;
            }
        }
    } else if (choice == 3) {
        std::string author = readLine("Enter Author (or part of it): ");
        std::string authorLower = toLower(author);
        for (const auto& b : books) {
            if (toLower(b.getAuthor()).find(authorLower) != std::string::npos) {
                if (!found) {
                    std::cout << std::left
                              << std::setw(6) << "ID" << std::setw(25) << "Title"
                              << std::setw(20) << "Author" << std::setw(15) << "Category"
                              << std::setw(15) << "ISBN" << std::setw(8) << "Year"
                              << std::setw(8) << "Total" << std::setw(10) << "Available" << std::endl;
                }
                b.display();
                found = true;
            }
        }
    } else {
        std::cout << "Invalid choice.\n";
        return;
    }

    if (!found) {
        std::cout << "No matching book(s) found.\n";
    }
}

void Library::updateBook() {
    std::cout << "\n--- Update Book Details ---\n";
    int id = readInt("Enter Book ID to update: ");
    int idx = findBookIndex(id);

    if (idx == -1) {
        std::cout << "Error: No book found with ID " << id << ".\n";
        return;
    }

    Book& b = books[idx];
    std::cout << "Leave field blank (press Enter) to keep the current value.\n";
    std::cout << "Current Title: " << b.getTitle() << "\nNew Title: ";
    std::string input;
    std::getline(std::cin, input);
    if (!input.empty()) b.setTitle(input);

    std::cout << "Current Author: " << b.getAuthor() << "\nNew Author: ";
    std::getline(std::cin, input);
    if (!input.empty()) b.setAuthor(input);

    std::cout << "Current Category: " << b.getCategory() << "\nNew Category: ";
    std::getline(std::cin, input);
    if (!input.empty()) b.setCategory(input);

    std::cout << "Current ISBN: " << b.getISBN() << "\nNew ISBN: ";
    std::getline(std::cin, input);
    if (!input.empty()) b.setISBN(input);

    std::cout << "Current Publication Year: " << b.getPublicationYear() << "\nNew Year (0 to keep current): ";
    int year;
    std::cin >> year;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (year > 0) b.setPublicationYear(year);

    std::cout << "Current Total Copies: " << b.getTotalCopies()
              << "\nNew Total Copies (0 to keep current): ";
    int totalCopies;
    std::cin >> totalCopies;
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    if (totalCopies > 0) {
        // Adjust available copies proportionally to avoid negative/overflowing values.
        int issuedCount = b.getTotalCopies() - b.getAvailableCopies();
        b.setTotalCopies(totalCopies);
        int newAvailable = totalCopies - issuedCount;
        b.setAvailableCopies(newAvailable > 0 ? newAvailable : 0);
    }

    saveBooksToFile();
    std::cout << "Success: Book details updated.\n";
}

void Library::deleteBook() {
    std::cout << "\n--- Delete Book ---\n";
    int id = readInt("Enter Book ID to delete: ");
    int idx = findBookIndex(id);

    if (idx == -1) {
        std::cout << "Error: No book found with ID " << id << ".\n";
        return;
    }

    // Prevent deleting a book that currently has copies issued out.
    for (const auto& issue : issues) {
        if (issue.bookID == id && issue.status == "Issued") {
            std::cout << "Error: Cannot delete this book — one or more copies are currently issued.\n";
            return;
        }
    }

    books.erase(books.begin() + idx);
    saveBooksToFile();
    std::cout << "Success: Book with ID " << id << " deleted.\n";
}

// ===========================================================
//                  Member Operations
// ===========================================================

void Library::registerMember() {
    std::cout << "\n--- Register New Member ---\n";

    int suggestedID = getNextMemberID();
    std::cout << "Assigned Member ID: " << suggestedID << "\n";

    std::string name = readLine("Enter Name: ");
    std::string phone = readLine("Enter Phone Number: ");
    std::string address = readLine("Enter Address: ");

    Member newMember(suggestedID, name, phone, address);
    members.push_back(newMember);
    saveMembersToFile();

    std::cout << "Success: Member registered with ID " << suggestedID << ".\n";
}

void Library::displayAllMembers() const {
    std::cout << "\n--- All Members (" << members.size() << ") ---\n";
    if (members.empty()) {
        std::cout << "No members registered yet.\n";
        return;
    }

    std::cout << std::left
              << std::setw(6)  << "ID"
              << std::setw(20) << "Name"
              << std::setw(15) << "Phone"
              << std::setw(30) << "Address"
              << std::endl;
    std::cout << std::string(71, '-') << std::endl;

    for (const auto& m : members) m.display();
}

void Library::deleteMember() {
    std::cout << "\n--- Delete Member ---\n";
    int id = readInt("Enter Member ID to delete: ");
    int idx = findMemberIndex(id);

    if (idx == -1) {
        std::cout << "Error: No member found with ID " << id << ".\n";
        return;
    }

    // Prevent deleting a member who currently has books issued.
    for (const auto& issue : issues) {
        if (issue.memberID == id && issue.status == "Issued") {
            std::cout << "Error: Cannot delete this member — they currently have book(s) issued.\n";
            return;
        }
    }

    members.erase(members.begin() + idx);
    saveMembersToFile();
    std::cout << "Success: Member with ID " << id << " deleted.\n";
}

// ===========================================================
//              Issue / Return Operations
// ===========================================================

void Library::issueBook() {
    std::cout << "\n--- Issue Book ---\n";

    int bookID = readInt("Enter Book ID: ");
    int bIdx = findBookIndex(bookID);
    if (bIdx == -1) {
        std::cout << "Error: No book found with ID " << bookID << ".\n";
        return;
    }

    int memberID = readInt("Enter Member ID: ");
    int mIdx = findMemberIndex(memberID);
    if (mIdx == -1) {
        std::cout << "Error: No member found with ID " << memberID << ".\n";
        return;
    }

    Book& book = books[bIdx];
    if (book.getAvailableCopies() <= 0) {
        std::cout << "Error: '" << book.getTitle() << "' is currently unavailable (0 copies left).\n";
        return;
    }

    // Create issue record.
    int issueID = getNextIssueID();
    std::string issueDate = getCurrentDate();
    IssueRecord record(issueID, bookID, memberID, issueDate, "N/A", "Issued");
    issues.push_back(record);

    // Reduce available copies.
    book.decrementAvailableCopies();

    saveIssuesToFile();
    saveBooksToFile();

    std::cout << "Success: Book '" << book.getTitle() << "' issued to member ID "
              << memberID << " (Issue ID: " << issueID << ").\n";
}

void Library::returnBook() {
    std::cout << "\n--- Return Book ---\n";

    int issueID = readInt("Enter Issue ID: ");

    int idx = -1;
    for (size_t i = 0; i < issues.size(); ++i) {
        if (issues[i].issueID == issueID) {
            idx = static_cast<int>(i);
            break;
        }
    }

    if (idx == -1) {
        std::cout << "Error: No issue record found with ID " << issueID << ".\n";
        return;
    }

    IssueRecord& record = issues[idx];
    if (record.status == "Returned") {
        std::cout << "Error: This book has already been returned.\n";
        return;
    }

    // Update issue record.
    record.status = "Returned";
    record.returnDate = getCurrentDate();

    // Increase available copies of the corresponding book.
    int bIdx = findBookIndex(record.bookID);
    if (bIdx != -1) {
        books[bIdx].incrementAvailableCopies();
        saveBooksToFile();
    }

    saveIssuesToFile();
    std::cout << "Success: Book returned for Issue ID " << issueID << ".\n";
}

void Library::displayIssuedBooks() const {
    std::cout << "\n--- Issued Books ---\n";

    bool anyIssued = false;
    std::cout << std::left
              << std::setw(10) << "IssueID"
              << std::setw(10) << "BookID"
              << std::setw(12) << "MemberID"
              << std::setw(14) << "IssueDate"
              << std::setw(14) << "ReturnDate"
              << std::setw(10) << "Status"
              << std::endl;
    std::cout << std::string(70, '-') << std::endl;

    for (const auto& record : issues) {
        if (record.status == "Issued") {
            record.display();
            anyIssued = true;
        }
    }

    if (!anyIssued) {
        std::cout << "No books are currently issued.\n";
    }
}

// ===========================================================
//                     Statistics
// ===========================================================

void Library::showStatistics() const {
    std::cout << "\n--- Library Statistics ---\n";
    std::cout << "Total Books (titles): " << books.size() << "\n";

    long totalCopies = 0, availableCopies = 0;
    for (const auto& b : books) {
        totalCopies += b.getTotalCopies();
        availableCopies += b.getAvailableCopies();
    }
    std::cout << "Total Book Copies: " << totalCopies << "\n";
    std::cout << "Available Copies: " << availableCopies << "\n";
    std::cout << "Total Members: " << members.size() << "\n";

    int issuedCount = 0;
    for (const auto& i : issues) if (i.status == "Issued") issuedCount++;
    std::cout << "Currently Issued Books: " << issuedCount << "\n";
}
